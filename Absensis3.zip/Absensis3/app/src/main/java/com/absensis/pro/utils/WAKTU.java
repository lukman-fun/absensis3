package com.absensis.pro.utils;

import java.util.Calendar;

public class WAKTU {
    int tahun, bulan, hari;

    public WAKTU(String date){
        String[] dates=date.split("-");
        tahun=Integer.parseInt(dates[0]);
        bulan=Integer.parseInt(dates[1]);
        hari=Integer.parseInt(dates[2]);
    }

    public String hari_indo(){
        Calendar cal=Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, hari);
        cal.set(Calendar.MONTH, bulan-1);
        cal.set(Calendar.YEAR, tahun);

        String[] hr= {"Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jum'at", "Sabtu"};
        return hr[cal.get(Calendar.DAY_OF_WEEK)-1];
    }

}
