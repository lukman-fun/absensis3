package com.absensis.pro.history;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.absensis.pro.R;
import com.absensis.pro.utils.WAKTU;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryHolder> {
    Context c;
    List<History> data;
    public HistoryAdapter(Context c) {
        this.c = c;
    }

    public void Update(List<History> data){
        this.data=data;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public HistoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new HistoryHolder(LayoutInflater.from(c).inflate(R.layout.item_history, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryHolder holder, int position) {
        holder.hari.setText(new WAKTU(data.get(position).getTgl_absensi()).hari_indo());
        holder.tgl.setText(data.get(position).getTgl_absensi());
        holder.jam_masuk.setText(": "+(data.get(position).getJam_masuk().equals("00:00:00") ? "-" : data.get(position).getJam_masuk().substring(0, 5)));
        holder.jam_pulang.setText(": "+(data.get(position).getJam_pulang().equals("00:00:00") ? "-" : data.get(position).getJam_pulang().substring(0, 5)));
        holder.telat.setText(": "+data.get(position).getTelat());
        holder.ket.setText(": "+data.get(position).getKeterangan());
    }

    @Override
    public int getItemCount() {
        return data!=null ? data.size() : 0;
    }

    public class HistoryHolder extends RecyclerView.ViewHolder {
        TextView hari, tgl, jam_masuk, jam_pulang, telat, ket;
        public HistoryHolder(@NonNull View v) {
            super(v);
            hari=v.findViewById(R.id.hari_absensi);
            tgl=v.findViewById(R.id.tgl_absensi);
            jam_masuk=v.findViewById(R.id.jam_masuk);
            jam_pulang=v.findViewById(R.id.jam_pulang);
            telat=v.findViewById(R.id.telat);
            ket=v.findViewById(R.id.keterangan);
        }
    }
}
