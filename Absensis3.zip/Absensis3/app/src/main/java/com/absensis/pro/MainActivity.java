package com.absensis.pro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.absensis.pro.history.History;
import com.absensis.pro.history.HistoryActivity;
import com.absensis.pro.utils.AUTH;
import com.absensis.pro.utils.CONSTRAINT;
import com.absensis.pro.utils.MAPSET;
import com.absensis.pro.utils.WAKTU;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, View.OnClickListener {
    GoogleMap map;
    TextView absen_masuk, absen_pulang, hadir, alfa, izin, sakit, telat;
    Button btnAbsen, btnHistory;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SupportMapFragment mapFragment=(SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.maps_absensi);
        mapFragment.getMapAsync(this);
        absen_masuk=findViewById(R.id.absen_masuk);
        absen_pulang=findViewById(R.id.absen_pulang);
        hadir=findViewById(R.id.hadir);
        alfa=findViewById(R.id.alfa);
        izin=findViewById(R.id.izin);
        sakit=findViewById(R.id.sakit);
        telat=findViewById(R.id.telat);
        btnAbsen=findViewById(R.id.btnAbsen);
        btnAbsen.setOnClickListener(this);
        btnHistory=findViewById(R.id.btnHistory);
        btnHistory.setOnClickListener(this);
        AndroidNetworking.initialize(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map=googleMap;
        getAbsensi();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnAbsen:
                startActivity(new Intent(getApplicationContext(), AbsensiActivity.class));
                break;
            case R.id.btnHistory:
//                Toast.makeText(getApplicationContext(), new WAKTU("2021-06-03").hari_indo(), Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), HistoryActivity.class));
                break;
        }
    }

    private void getAbsensi(){
        AndroidNetworking.get(CONSTRAINT.BASE_URL +"getAbsensi&id_pegawai="+new AUTH(this).get())
                .setPriority(Priority.LOW)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            // ABSENSI
                            JSONObject absensi=response.getJSONObject("absensi");
                            if(absensi.getString("status").equals("200")){
                                JSONObject data=absensi.getJSONObject("data");
                                absen_masuk.setText(data.getString("jam_masuk").equals("00:00:00") ? "-" : data.getString("jam_masuk").substring(0, 5));
                                absen_pulang.setText(data.getString("jam_pulang").equals("00:00:00") ? "-" : data.getString("jam_pulang").substring(0, 5));

                                //TOMBOL ABSENSI
                                if(!data.getString("jam_masuk").equals("00:00:00")&&!data.getString("jam_pulang").equals("00:00:00")){
                                    btnAbsen.setVisibility(View.INVISIBLE);
                                }else{
                                    btnAbsen.setVisibility(View.VISIBLE);
                                }

                            }else{
                                absen_masuk.setText("-");
                                absen_pulang.setText("-");
                            }

                            //LOKASI
                            JSONObject lokasi=response.getJSONObject("lokasi");
                            if(lokasi.getString("status").equals("200")){
                                JSONObject data=lokasi.getJSONObject("data");
                                LatLng lastPosition=new LatLng(Double.parseDouble(data.getString("latitude")), Double.parseDouble(data.getString("longitude")));
                                MarkerOptions lastMarker=new MarkerOptions()
                                        .position(lastPosition)
                                        .title("Posisi Terakhir Absensi Online")
                                        .icon(BitmapDescriptorFactory.defaultMarker(201));
                                map.addMarker(lastMarker);
                                CameraUpdate cam= CameraUpdateFactory.newLatLngZoom(lastPosition, 20);
                                map.animateCamera(cam);
                            }

                            JSONObject rekap=response.getJSONObject("rekap");
                            hadir.setText(": "+rekap.getString("hadir"));
                            alfa.setText(": "+rekap.getString("alfa"));
                            izin.setText(": "+rekap.getString("izin"));
                            sakit.setText(": "+rekap.getString("sakit"));
                            telat.setText(": "+rekap.getString("telat"));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        Toast.makeText(getApplicationContext(), anError.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.logout:
                AlertDialog.Builder builder=new AlertDialog.Builder(this);
                builder.setMessage("Apakah anda yakin ingin logout dari akun ini?");
                builder.setPositiveButton("Logout", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        new AUTH(getApplicationContext()).rmv();
                        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                        finish();
                        dialog.cancel();
                    }
                });
                builder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.setCancelable(false);
                builder.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}