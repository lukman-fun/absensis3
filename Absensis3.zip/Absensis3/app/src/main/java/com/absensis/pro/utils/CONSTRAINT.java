package com.absensis.pro.utils;

public class CONSTRAINT {
    public static final String BASE_URL="http://192.168.0.12/absensis/api.php?load=";
}