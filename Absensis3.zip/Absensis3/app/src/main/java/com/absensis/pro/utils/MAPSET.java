package com.absensis.pro.utils;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;

public class MAPSET {
    // KOORDINAT LOKASI ABSENSI ONLINE
    public static final String NAMA = "Tempat Absensi Online";
    public static final int RADIUS = 30; //Dalam Meter
    public static final double LATITUDE = -6.962012;
    public static final double LONGITUDE = 112.353914;
    public static final String JAM_ABSEN = "08:00:00";

    // POLYGON LOKASI ABSENSI ONLINE
    public static List<LatLng> polygonList=new ArrayList<>();
    public static final List<LatLng> getPolygonList(){
        polygonList.add(new LatLng(-6.961874, 112.353858));
        polygonList.add(new LatLng(-6.961951, 112.353750));
        polygonList.add(new LatLng(-6.962204, 112.353729));
        polygonList.add(new LatLng(-6.962265, 112.354016));
        polygonList.add(new LatLng(-6.962137, 112.354128));
        polygonList.add(new LatLng(-6.961983, 112.354091));
        polygonList.add(new LatLng(-6.961900, 112.354013));
        return polygonList;
    }
}
