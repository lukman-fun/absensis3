package com.absensis.pro;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.absensis.pro.utils.AUTH;
import com.absensis.pro.utils.CONSTRAINT;
import com.absensis.pro.utils.MAPSET;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.tasks.OnSuccessListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class AbsensiActivity extends AppCompatActivity implements OnMapReadyCallback, View.OnClickListener, LocationListener {
    GoogleMap map;
    List<LatLng> polyList=new ArrayList<>();
    Polygon polygon=null;
    LocationManager locationManager;

    private final int MIN_WAKTU=1000; //1 Detik
    private final int MIN_JARAK=1; //1 Meter
    private final int LOCATION_REQ=10101;

    Marker userPosition;
    FusedLocationProviderClient fusedLocationProviderClient;
    Location koorLocation;

    LinearLayout lnAbsensi;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_absensi);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        SupportMapFragment mapFragment=(SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.maps_start_absensi);
        mapFragment.getMapAsync(this);
        locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        lnAbsensi=findViewById(R.id.lnAbsensi);
        lnAbsensi.setOnClickListener(this);
        fusedLocationProviderClient= LocationServices.getFusedLocationProviderClient(this);
        AndroidNetworking.initialize(this);
        getUpdateLocation();
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map=googleMap;
        fusedLocationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                userPosition=map.addMarker(new MarkerOptions().position(new LatLng(location.getLatitude(), location.getLongitude())).title("Posisi Saya").icon(BitmapDescriptorFactory.defaultMarker(201)));
            }
        });

//        userPosition=map.addMarker(new MarkerOptions().position(new LatLng(-6.962482, 112.354478)).title("Posisi Saya"));


        koorLocation=new Location(MAPSET.NAMA);
        koorLocation.setLatitude(MAPSET.LATITUDE);
        koorLocation.setLongitude(MAPSET.LONGITUDE);

        LatLng latLngKoor=new LatLng(MAPSET.LATITUDE, MAPSET.LONGITUDE);
        MarkerOptions markerKoor=new MarkerOptions();
        markerKoor.position(latLngKoor);
        markerKoor.title(MAPSET.NAMA);
        map.addMarker(markerKoor);
        CameraUpdate loc= CameraUpdateFactory.newLatLngZoom(latLngKoor, 20);
        map.animateCamera(loc);


        if(polygon!=null) polygon.remove();
        PolygonOptions polygonOptions=new PolygonOptions().addAll(MAPSET.getPolygonList()).clickable(true);
        polygon=map.addPolygon(polygonOptions);
        polygon.setStrokeColor(getResources().getColor(R.color.purple_700));
        polygon.setFillColor(getResources().getColor(R.color.purple_700));
    }

    public void getUpdateLocation(){
        if(locationManager!=null){
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                if(locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_WAKTU, MIN_JARAK, this);
                }else if(locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)){
                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, MIN_WAKTU, MIN_JARAK, this);
                }else{
                    Toast.makeText(getApplicationContext(), "Tidak Ada Provider yang AKtif", Toast.LENGTH_SHORT).show();
                }
            }else{
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQ);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==LOCATION_REQ){
            if( grantResults.length>0 && (grantResults[0]== PackageManager.PERMISSION_GRANTED&&grantResults[1]==PackageManager.PERMISSION_GRANTED) ){
                getUpdateLocation();
            }else{
                Toast.makeText(getApplicationContext(), "Permission Required", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        if(location!=null){
            if(userPosition!=null){
                float distance=location.distanceTo(koorLocation);
                int jarak=(int)Math.floor(distance); //Meter
                if(jarak< MAPSET.RADIUS){
                    lnAbsensi.setVisibility(View.VISIBLE);
                }else{
                    lnAbsensi.setVisibility(View.GONE);
                }
                userPosition.setPosition(new LatLng(location.getLatitude(), location.getLongitude()));
            }
        }else{
            Toast.makeText(getApplicationContext(), "Tidak Ada Lokasi", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {

    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {

    }

    @Override
    public void onClick(View v) {
        JSONObject absensi=new JSONObject();
        try {
            absensi.put("id_pegawai", new AUTH(this).get());
            absensi.put("keterangan", "hadir");
            absensi.put("latitude", userPosition.getPosition().latitude);
            absensi.put("longitude", userPosition.getPosition().longitude);
            absensi.put("telat", selisih());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        AndroidNetworking.post(CONSTRAINT.BASE_URL+"goAbsensi")
                .addJSONObjectBody(absensi)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Toast.makeText(getApplicationContext(), "Absnsi Berhasil", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        finish();
                    }

                    @Override
                    public void onError(ANError anError) {
                        Toast.makeText(getApplicationContext(), anError.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private String selisih(){
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        Long diff = null;
        try {
            Date awal=simpleDateFormat.parse(simpleDateFormat.format(new Date()).substring(0, 11)+" "+MAPSET.JAM_ABSEN);
            Date akhir=simpleDateFormat.parse(simpleDateFormat.format(new Date()));

            diff=akhir.getTime()-awal.getTime();
//            Toast.makeText(getApplicationContext(), "SELISIH : "+ TimeUnit.MILLISECONDS.toMinutes(diff), Toast.LENGTH_SHORT).show();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return String.valueOf(TimeUnit.MILLISECONDS.toMinutes(diff));
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    
}
