package com.absensis.pro.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class AUTH {
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    public AUTH(Context c){
        sharedPreferences=c.getSharedPreferences("log", c.MODE_PRIVATE);
    }

    public void set(String id){
        editor= sharedPreferences.edit();
        editor.putString("id", id);
        editor.commit();
    }

    public String get(){
        return sharedPreferences.getString("id", null);
    }

    public boolean valid(){
        return sharedPreferences.getString("id", null) != null ? true : false;
    }

    public void rmv(){
        editor=sharedPreferences.edit();
        editor.remove("id");
        editor.commit();
    }
}
