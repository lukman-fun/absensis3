package com.absensis.pro.history;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.absensis.pro.LoginActivity;
import com.absensis.pro.R;
import com.absensis.pro.utils.AUTH;
import com.absensis.pro.utils.CONSTRAINT;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    RecyclerView rvHistory;
    List<History> data=new ArrayList<>();
    HistoryAdapter adapter;
    ProgressDialog pd;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        rvHistory=findViewById(R.id.rvHistory);
        rvHistory.setLayoutManager(new LinearLayoutManager(this));
        rvHistory.setHasFixedSize(true);
        adapter=new HistoryAdapter(this);
        rvHistory.setAdapter(adapter);
        pd=new ProgressDialog(this);
        pd.setMessage("Loading...");
        pd.setCancelable(false);
        getHistory();
    }

    private void getHistory(){
        pd.show();
        AndroidNetworking.get(CONSTRAINT.BASE_URL+"getHistory&id_pegawai="+new AUTH(this).get())
                .setPriority(Priority.LOW)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            pd.cancel();
                            if(response.getString("status").equals("200")){
                                data.clear();
                                JSONArray ja=response.getJSONArray("data");
                                for(int i=0;i<ja.length();i++){
                                    JSONObject jo=ja.getJSONObject(0);
                                    data.add(new History(
                                            jo.getString("id_absensi"),
                                            jo.getString("tgl_absensi"),
                                            jo.getString("jam_masuk"),
                                            jo.getString("jam_pulang"),
                                            jo.getString("telat"),
                                            jo.getString("keterangan").toUpperCase()
                                    ));
                                    adapter.Update(data);
                                }
                            }else{
                                Toast.makeText(getApplicationContext(), "Data Kosongg", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        pd.cancel();
                        Toast.makeText(getApplicationContext(), anError.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
