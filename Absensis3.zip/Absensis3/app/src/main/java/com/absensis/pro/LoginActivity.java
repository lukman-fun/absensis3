package com.absensis.pro;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.absensis.pro.utils.AUTH;
import com.absensis.pro.utils.CONSTRAINT;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Collections;
import java.util.List;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    int REQ_READ_PHONE=1001;
    EditText username, password;
    TextView toDaftar;
    Button btnLogin;
    ProgressDialog pd;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
        username=findViewById(R.id.username);
        password=findViewById(R.id.password);
        btnLogin=findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);
        toDaftar=findViewById(R.id.toDaftar);
        toDaftar.setOnClickListener(this);
        pd=new ProgressDialog(this);
        pd.setMessage("Loading....");
        pd.setCancelable(false);
        AndroidNetworking.initialize(this);
        if(new AUTH(this).valid()){
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnLogin:
                login();
                break;
            case R.id.toDaftar:
                startActivity(new Intent(getApplicationContext(), DaftarActivity.class));
                finish();
                break;
        }
    }

    private void login(){
        pd.setMessage("Loading...");
        pd.show();
        JSONObject datas=new JSONObject();
        try {
            datas.put("username", username.getText().toString());
            datas.put("password", password.getText().toString());
            datas.put("imei", uniqid());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        AndroidNetworking.post(CONSTRAINT.BASE_URL+"login")
                .setPriority(Priority.MEDIUM)
                .addJSONObjectBody(datas)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        pd.cancel();
                        try {
                            if(response.getString("status").equals("200")){
                                new AUTH(getApplicationContext()).set(response.getJSONObject("data").getString("id_pegawai"));
                                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                                finish();
                            }else{
                                Toast.makeText(getApplicationContext(), response.getString("msg"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        pd.cancel();
                        Toast.makeText(getApplicationContext(), anError.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private String uniqid(){
        String data="";
        try {
            List<NetworkInterface> networkInterfaceList= Collections.list(NetworkInterface.getNetworkInterfaces());
            for(NetworkInterface networkInterface : networkInterfaceList){
                if(networkInterface.getName().equalsIgnoreCase("wlan0")){
                    for(int i=0;i<networkInterface.getHardwareAddress().length;i++){
                        String macByte=Integer.toHexString(networkInterface.getHardwareAddress()[i]&0xFF);
                        if(macByte.length()==1){
                            macByte="0"+macByte;
                        }
                        data+=macByte.toUpperCase()+":";
                    }
                    break;
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }
        return data;
    }

}
