package com.absensis.pro;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.absensis.pro.utils.CONSTRAINT;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

public class DaftarActivity extends AppCompatActivity implements View.OnClickListener {
    EditText username, nama, tgl_lahir, alamat, imei, no_hp, password;
    Spinner jenis_kelamin, jabatan;
    Button btnDaftar;
    TextView toLogin;
    int mThn, mBln, mHr;
    String[] idJabatan, namaJabatan;
    ProgressDialog pd;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar);
        getSupportActionBar().hide();
        username=findViewById(R.id.username);
        nama=findViewById(R.id.nama);
        tgl_lahir=findViewById(R.id.tgl_lahir);
        tgl_lahir.setOnClickListener(this);
        jenis_kelamin=findViewById(R.id.jenis_kelamin);
        alamat=findViewById(R.id.alamat);
        jabatan=findViewById(R.id.jabatan);
        imei=findViewById(R.id.imei);
        imei.setText(uniqid());
        no_hp=findViewById(R.id.no_hp);
        password=findViewById(R.id.password);
        btnDaftar=findViewById(R.id.btnDaftar);
        btnDaftar.setOnClickListener(this);
        toLogin=findViewById(R.id.toLogin);
        toLogin.setOnClickListener(this);
        pd=new ProgressDialog(this);
        pd.setCancelable(false);
        pd.setMessage("Loading...");
        AndroidNetworking.initialize(this);
        getJabatan();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tgl_lahir:
                datepick();
                break;
            case R.id.btnDaftar:
                daftar();
                break;
            case R.id.toLogin:
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                finish();
                break;
        }
    }

    private void datepick(){
        final Calendar cal= Calendar.getInstance();
        mThn=cal.get(Calendar.YEAR);
        mBln=cal.get(Calendar.MONTH);
        mHr=cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog=new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                tgl_lahir.setText(year+"-"+String.format("%02d", month)+"-"+String.format("%02d", dayOfMonth));
            }
        }, mThn, mBln, mHr);
        datePickerDialog.show();
    }

    private void getJabatan(){
        pd.setMessage("Loading...");
        pd.show();
        AndroidNetworking.get(CONSTRAINT.BASE_URL+"getJabatan")
                .setPriority(Priority.LOW)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        pd.cancel();
                        try {
                            if(response.getString("status").equals("200")){
                                JSONArray ja=response.getJSONArray("data");
                                idJabatan=new String[ja.length()];
                                namaJabatan=new String[ja.length()];
                                for(int i=0;i<ja.length();i++){
                                    JSONObject jo=ja.getJSONObject(i);
                                    idJabatan[i]=jo.getString("id_jabatan");
                                    namaJabatan[i]=jo.getString("jabatan");
                                }
                                ArrayAdapter<String> adapter=new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, namaJabatan);
                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                jabatan.setAdapter(adapter);
                            }else{
                                Toast.makeText(getApplicationContext(), response.getString("msg"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        pd.cancel();
                        Toast.makeText(getApplicationContext(), anError.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void daftar(){
        pd.setMessage("Loading...");
        pd.show();
        JSONObject datas=new JSONObject();
        try {
            datas.put("username", username.getText().toString());
            datas.put("nama_pegawai", nama.getText().toString());
            datas.put("tanggal_lahir", tgl_lahir.getText().toString());
            datas.put("jenis_kelamin", jenis_kelamin.getSelectedItem().toString());
            datas.put("alamat", alamat.getText().toString());
            datas.put("id_jabatan", idJabatan[jabatan.getSelectedItemPosition()]);
            datas.put("imei", imei.getText().toString());
            datas.put("no_hp", no_hp.getText().toString());
            datas.put("password", password.getText().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        AndroidNetworking.post(CONSTRAINT.BASE_URL+"daftar")
                .setPriority(Priority.MEDIUM)
                .addJSONObjectBody(datas)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        pd.cancel();
                        try {
                            if(response.getString("status").equals("200")){
                                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                                finish();
                            }
                            Toast.makeText(getApplicationContext(), response.getString("msg"), Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        pd.cancel();
                        Toast.makeText(getApplicationContext(), anError.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private String uniqid(){
        String data="";
        try {
            List<NetworkInterface> networkInterfaceList= Collections.list(NetworkInterface.getNetworkInterfaces());
            for(NetworkInterface networkInterface : networkInterfaceList){
                if(networkInterface.getName().equalsIgnoreCase("wlan0")){
                    for(int i=0;i<networkInterface.getHardwareAddress().length;i++){
                        String macByte=Integer.toHexString(networkInterface.getHardwareAddress()[i]&0xFF);
                        if(macByte.length()==1){
                            macByte="0"+macByte;
                        }
                        data+=macByte.toUpperCase()+":";
                    }
                    break;
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }
        return data;
    }

}
