package com.absensis.pro.history;

public class History {
    String id, tgl_absensi, jam_masuk, jam_pulang, telat, keterangan;

    public History(String id, String tgl_absensi, String jam_masuk, String jam_pulang, String telat, String keterangan) {
        this.id = id;
        this.tgl_absensi = tgl_absensi;
        this.jam_masuk = jam_masuk;
        this.jam_pulang = jam_pulang;
        this.telat = telat;
        this.keterangan = keterangan;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTgl_absensi() {
        return tgl_absensi;
    }

    public void setTgl_absensi(String tgl_absensi) {
        this.tgl_absensi = tgl_absensi;
    }

    public String getJam_masuk() {
        return jam_masuk;
    }

    public void setJam_masuk(String jam_masuk) {
        this.jam_masuk = jam_masuk;
    }

    public String getJam_pulang() {
        return jam_pulang;
    }

    public void setJam_pulang(String jam_pulang) {
        this.jam_pulang = jam_pulang;
    }

    public String getTelat() {
        return telat;
    }

    public void setTelat(String telat) {
        this.telat = telat;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }
}
